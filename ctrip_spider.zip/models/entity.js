var helper = require('../helpers/webhelper.js')
exports.hotel=function(){
    this.city="";
    this.id = 0;
    this.name = "";
    this.shortName = "";
    this.star=0;
    this.currency = "";
    this.lowPrice="";
    this.points="";
    this.zoneName="";
    this.picCount=0;
    this.commentCount=0;

    this.isGift=false;
    this.isNew=false;
    this.isFan=false;
    this.fanPrice=0;
    this.fanType="";
    this.isQuan=false;
    this.quanPrice=0;
    this.quanType="";
    this.isCu = false;
    this.isMp=false;
    this.isMorning=false;
    this.isStar=false;
    this.isRoomFull=false;

    
    this.faclPoints= "0";//设施
    this.raAtPoints = "0";//环境
    this.ratPoints = "0";//卫生
    this.servPoints = "0";//服务
    this.rooms = [];
};
exports.hotel.prototype.toString=function(site){
    if(site=='elong'){
        var sb = new helper.StringBuffer();
        for(var i=0;i<this.rooms.length;i++){
            sb.append(this.city);
            sb.append(',');
            sb.append(this.name);
            sb.append(',');
            sb.append(this.star);
            sb.append(',');
            sb.append(this.rooms[i].name);
            sb.append(',');
            sb.append(this.rooms[i].price);
            sb.append(',');
            sb.append(this.rooms[i].fan);
            sb.append(',');
            sb.append(this.commentCount);
            sb.append(',');
            sb.append(this.prate);
            sb.append(',');
            sb.append(this.picCount);
            sb.append(',');
            sb.append(this.payType==0?'Y':'N');
            sb.append(',');
            sb.append(this.rooms[i].sjzx=='Y'?'Y':'N')
            sb.append(',');
            sb.append(this.rooms[i].jrtj=='Y'?'Y':'N');
            sb.append(',');
            if(this.rooms[i].breakfast=='无早')
                sb.append('0');
            else if(this.rooms[i].breakfast=='双早')
                sb.append('2');
            else if(this.rooms[i].breakfast=='单早')
                sb.append('1');
            
            sb.append(',');
            sb.append(this.rooms[i].lan);
            sb.append('\r\n');
        }
        return sb.toString();
    }
    else if(site=="qunar"){
        var sb = new helper.StringBuffer();
        for(var i=0;i<this.rooms.length;i++){
            var r = this.rooms[i];
            for(var j=0;j<r.sites.length;j++){
                sb.append(this.city);
                sb.append(',');
                sb.append(this.name);
                sb.append(',');
                sb.append(this.star);
                sb.append(',');
                sb.append(r.name);
                sb.append(',');
                sb.append(r.sites[j].site)
                sb.append(',');
                sb.append(r.sites[j].price);
                sb.append(',');
                sb.append(this.commentCount);
                sb.append(',');
                sb.append(this.points);
                sb.append(',');
                sb.append(r.sites[j].tuan);
                sb.append('\r\n');
            }
        }
        return sb.toString();
    }
    else if(site=="elong_pc"){
        var sb = new helper.StringBuffer();
        for(var i = 0;i<this.rooms.length;i++){
            var r = this.rooms[i];
            for(var j=0;j<r.plans.length;j++){
                sb.append(this.city);
                sb.append(',');
                sb.append(this.name);
                sb.append(',');
                sb.append(this.zoneName);
                sb.append(',');
                sb.append(this.star);
                sb.append(',');
                sb.append(r.name);
                sb.append(',');
                sb.append(r.bedType);
                sb.append(',');
                sb.append(this.commentCount);
                sb.append(',');
                sb.append(this.goodComment);
                sb.append(',');
                sb.append(this.badComment);
                sb.append(',');
                sb.append(this.prate);
                sb.append(',');
                sb.append(r.plans[j].name);
                sb.append(',');
                sb.append(r.plans[j].breakfast);
                sb.append(',');
                sb.append(r.plans[j].price);
                sb.append(',');
                sb.append(r.plans[j].fan);
                sb.append(',');
                sb.append(r.plans[j].lan);
                sb.append(',');
                sb.append(r.plans[j].payType);
                sb.append(',');
                sb.append(r.plans[j].hasWeifang);
                sb.append(',');
                sb.append(r.plans[j].needSurety);
                sb.append(',');
                sb.append(r.plans[j].gift.replace(/,/g,''));
                sb.append(',');
                sb.append(r.plans[j].reduce);
                sb.append(',');
                sb.append(r.plans[j].timeLimit);
                sb.append('\r\n');
            }
        }
        return sb.toString();
    }
    var sb="";
    for(var i=0;i<this.rooms.length;i++){
        sb+=this.city+",";
        
        sb+=this.name+",";
        
        sb+=(this.zoneName==null?"":this.zoneName)+",";
        
        sb+=this.star+',';
        
        sb+=this.rooms[i].name+',';
        
        sb+=this.rooms[i].price+',';
        
        sb+=this.commentCount+',';
        
        sb+=this.picCount+',';
        
        sb+=this.points+',';
        
        sb+=this.faclPoints+',';
        
        sb+=this.raAtPoints+',';
        
        sb+=this.servPoints+',';
        
        sb+=this.ratPoints+',';
        
        var b;
        if(this.rooms[i].breakfast=="单早")
            b=1;
        else if(this.rooms[i].breakfast=="双早")
            b=2;
        else b=0;
        sb+=b+',';
        
        if(this.rooms[i].gift)
            sb+=this.rooms[i].gift+',';
        else sb+=',';
        
        sb+=(this.isCu==0?"N":"Y")+',';
        
        if(this.rooms[i].fanPrice)
            sb+=this.rooms[i].fanPrice+',';
        else sb+=",";
        
        sb+=(this.rooms[i].payType==0?"Y":"N");
        sb+='\r\n';
    }
    return sb;
}

exports.room = function(){
    this.id=0;
    this.name="";
    this.breakfast="";
    this.fan="";
    this.gift="";
    this.isCu=0;
    this.payType=1;
    this.price="";
};

exports.flight = function(){
    this.aPortCode='';
    this.aTerminal='';
    this.aTime='';
    this.aaname='';
    this.airlineCode='';
    this.aname='';
    this.cmpName='';
    this.cabins=[];
    this.ctinfo=[];
    this.dPortCode='PEK';
    this.dTerminal=null;
    this.dTime='2014/2/23 6:35:00';
    this.daname='首都';
    this.flag=0;
    this.flightNo='HO1252';
    this.planeType='320';
    this.puncRate=93;
    this.stopCities=null;
    this.price = '';
};

exports.flight.prototype.toString=function(){
    var sb = new helper.StringBuffer();
    for(var i=0;i<this.cabins.length;i++){
        sb.append(this.dname);
        sb.append(',');
        sb.append(this.aname);
        sb.append(',');
        sb.append(this.cmpName);
        sb.append(this.flightNo);
        sb.append(',');
        sb.append(this.dTime);
        sb.append(',');
        sb.append(this.aTime);
        sb.append(',');
        sb.append(this.price);
        sb.append(',');
        sb.append(this.cabins[i].tui.replace(/[,]*/g,''));
        sb.append(',');
        sb.append(this.cabins[i].gai.replace(/[,]*/g,''));
        sb.append(',');
        sb.append(this.cabins[i].ctype);
        sb.append(',');
        sb.append(this.cabins[i].price);
        sb.append(',');
        sb.append(this.cabins[i].tCount);
        sb.append('\r\n');
    }
    var result = sb.toString();
    sb=null;
    return result;
};