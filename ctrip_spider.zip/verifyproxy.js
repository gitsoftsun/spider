var helper = require('./helpers/webhelper.js')

helper.verifyproxy('proxys-2-24.txt','verified-2-24.txt');